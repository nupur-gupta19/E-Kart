import React from "react";
import './fashion/fashion.css';

function footer(){
   
     
return(

<footer id="footer" className="bg-light mt-5">
    <div className="empty-container"></div>
    <div className="container" style={{padding:"20px"}}><hr></hr></div>
    <div className="container-fluid bg-light">
        <div className="row mx-2">
        <div className="col-md-3">
        <dl>
        <dd><h5>Store</h5></dd>
        <dd><h2><a href="/"className="linkStyle">E-Kart</a></h2></dd>
        <dd>888 - 963 - 600</dd>
        <dd>info@example.com</dd>
        </dl>
        </div>
        <div className="col-md-3">
        <dl>
        <dd><h6>Info</h6></dd>
        <dd><a href="/" className="linkStyle">Home</a></dd>
        <dd><a className="linkStyle">Blog</a></dd>
        <dd><a className="linkStyle">About Us</a></dd>
        <dd><a className="linkStyle">Contact Us</a></dd>
        </dl>
        </div>
        <div className="col-md-3">
        <dl>
        <dd><h6>Our Polices</h6></dd>
        <dd><a>FAQs</a></dd>
        <dd><a>Privacy Policy</a></dd>
        <dd><a>Refund Policy</a></dd>
        <dd><a>Terms of Service</a></dd>
        </dl>
        </div>
        <div className="col-md-3">
        <dl>
        <dd><h6>Social Network</h6></dd>
        <dd><a>Facebook</a></dd>
        <dd><a>Twitter</a></dd>
        <dd><a>Instagram</a></dd>
        <dd><a>Linkedin</a></dd>
        </dl>
        </div>
        </div>
    </div>
</footer>
);
}
export default footer;
